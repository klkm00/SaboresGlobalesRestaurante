package com.example.RestauranteSaboresGlobales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestauranteSaboresGlobalesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestauranteSaboresGlobalesApplication.class, args);
	}

}
